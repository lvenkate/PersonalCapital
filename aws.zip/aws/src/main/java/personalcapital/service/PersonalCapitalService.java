package personalcapital.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import personalcapital.dto.PersonalCapital;
import personalcapital.dto.request.MyRequestBody;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Service
@Component("personalCapitalService")
public class PersonalCapitalService {

    private RestHighLevelClient client;
    private ObjectMapper objectMapper;

    @Autowired
    public PersonalCapitalService(final RestHighLevelClient client, ObjectMapper objectMapper) {
        this.client = client;
        this.objectMapper = objectMapper;
    }

    public List<PersonalCapital> retrieve(final MyRequestBody request) {

            SearchRequest searchRequest = new SearchRequest();
            SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();

            QueryBuilder queryBuilder = QueryBuilders
                    .boolQuery()
                    .must(QueryBuilders
                            .matchQuery("SPONS_DFE_LOC_US_STATE", request.getSponsorState()))
                    .must(QueryBuilders
                            .matchQuery("PLAN_NAME", request.getPlanName()))
                    .must(QueryBuilders
                            .matchQuery("SPONSOR_DFE_NAME", request.getSponsorName()));

            searchRequest.source(searchSourceBuilder.query(queryBuilder));
        SearchResponse response =
                null;
        try {
            response = client.search(searchRequest, RequestOptions.DEFAULT);
        } catch (IOException e) {
            e.printStackTrace();
        }


        return getSearchResult(response);
    }

    private List<PersonalCapital> getSearchResult(SearchResponse response) {

        SearchHit[] searchHit = response.getHits().getHits();

        List<PersonalCapital> profileDocuments = new ArrayList<>();

        if (searchHit.length > 0) {

            Arrays.stream(searchHit)
                    .forEach(hit -> {
                                profileDocuments
                                        .add(objectMapper.convertValue(hit.getSourceAsMap(),
                                                        PersonalCapital.class));
                            }
                    );
        }

        return profileDocuments;
    }


}
