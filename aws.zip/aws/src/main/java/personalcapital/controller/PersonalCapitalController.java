package personalcapital.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import personalcapital.dto.request.MyRequestBody;
import personalcapital.service.PersonalCapitalService;

@RestController("/api/v1/personalcapital")
public class PersonalCapitalController {

    private PersonalCapitalService service;

    @Autowired
    public PersonalCapitalController(@Qualifier("personalCapitalService") final PersonalCapitalService personalCapitalService) {

        this.service = personalCapitalService;
    }

    @PostMapping
    public ResponseEntity createProfile(@RequestBody MyRequestBody request) throws Exception {

        return new ResponseEntity(service.retrieve(request), HttpStatus.CREATED);
    }
}


