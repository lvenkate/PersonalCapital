package personalcapital.dto.request;

import lombok.Data;

@Data
public class MyRequestBody {

    private String planName;

    private String sponsorName;

    private String sponsorState;
}
