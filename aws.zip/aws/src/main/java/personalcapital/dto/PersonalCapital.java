package personalcapital.dto;


import lombok.Data;

import java.util.Date;

@Data
public class PersonalCapital {

    Long ackId;
    Date formPlanYearBeginDate;
    String planName;
    String sponsorDfEname;
    String sponsDfEdbaName;
    String sponsDfEcareOfName;
    String sponsDfEmailUsAddress1;
    String sponsDfEmailUsAddress2;


}
